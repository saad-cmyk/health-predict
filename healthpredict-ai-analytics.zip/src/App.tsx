import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  FileText, 
  TrendingUp, 
  PlusCircle, 
  Search, 
  User, 
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
  BrainCircuit,
  Database,
  Plus,
  X,
  ShieldAlert,
  Stethoscope,
  Heart,
  Dna,
  Layers,
  RotateCw
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { getHealthPrediction, type HealthPrediction } from './services/geminiService';
import { motion, AnimatePresence } from 'framer-motion';
import toast, { Toaster } from 'react-hot-toast';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Patient {
  id: number;
  name: string;
  age: number;
  gender: string;
  blood_type: string;
}

interface Report {
  id: number;
  patient_id: number;
  report_date: string;
  symptoms: string;
  diagnosis: string;
  prediction_score: number;
  recovery_days: number;
}

export default function App() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [reports, setReports] = useState<Report[]>([]);
  const [trendData, setTrendData] = useState<any[]>([]);
  const [filteredTrendData, setFilteredTrendData] = useState<any[]>([]);
  const [monthFilter, setMonthFilter] = useState('All');
  const [symptoms, setSymptoms] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [prediction, setPrediction] = useState<HealthPrediction | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reports' | 'analyze' | 'anatomy'>('dashboard');
  const [isAddPatientOpen, setIsAddPatientOpen] = useState(false);
  const [newPatient, setNewPatient] = useState({ name: '', age: '', gender: 'Male', blood_type: 'A+' });
  const [isSubmittingPatient, setIsSubmittingPatient] = useState(false);

  useEffect(() => {
    fetchPatients();
    fetchTrends();
  }, []);

  useEffect(() => {
    if (selectedPatient) {
      fetchReports(selectedPatient.id);
    }
  }, [selectedPatient]);

  const fetchPatients = async () => {
    try {
      const res = await fetch('/api/patients');
      if (!res.ok) throw new Error('Failed to fetch patients');
      const data = await res.json();
      setPatients(data);
      if (data.length > 0 && !selectedPatient) setSelectedPatient(data[0]);
    } catch (error) {
      toast.error('Error fetching patients. Please check your connection.');
      console.error(error);
    }
  };

  const fetchReports = async (id: number) => {
    try {
      const res = await fetch(`/api/reports/${id}`);
      if (!res.ok) throw new Error('Failed to fetch reports');
      const data = await res.json();
      setReports(data);
    } catch (error) {
      toast.error('Error fetching clinical reports.');
      console.error(error);
    }
  };

  const fetchTrends = async () => {
    try {
      const res = await fetch('/api/analytics/trends');
      if (!res.ok) throw new Error('Failed to fetch trend data');
      const data = await res.json();
      setTrendData(data);
      setFilteredTrendData(data);
    } catch (error) {
      console.error('Trend data fetch error:', error);
    }
  };

  useEffect(() => {
    if (monthFilter === 'All') {
      setFilteredTrendData(trendData);
    } else {
      setFilteredTrendData(trendData.filter(d => d.month === monthFilter));
    }
  }, [monthFilter, trendData]);

  const handleAddPatient = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Client-side validation
    if (!newPatient.name.trim()) {
      toast.error('Please enter a patient name');
      return;
    }
    const ageNum = parseInt(newPatient.age);
    if (isNaN(ageNum) || ageNum <= 0 || ageNum > 150) {
      toast.error('Please enter a valid age (1-150)');
      return;
    }

    setIsSubmittingPatient(true);
    try {
      const res = await fetch('/api/patients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newPatient,
          age: ageNum
        })
      });
      if (!res.ok) throw new Error('Failed to add patient');
      toast.success('Patient added successfully');
      setIsAddPatientOpen(false);
      setNewPatient({ name: '', age: '', gender: 'Male', blood_type: 'A+' });
      fetchPatients();
    } catch (error) {
      toast.error('Failed to add patient. Please try again.');
      console.error(error);
    } finally {
      setIsSubmittingPatient(false);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedPatient || !symptoms) return;
    setIsAnalyzing(true);
    try {
      const result = await getHealthPrediction(symptoms, selectedPatient);
      setPrediction(result);
      
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: selectedPatient.id,
          symptoms,
          diagnosis: result.diagnosis,
          predictionScore: result.predictionScore,
          recoveryDays: result.recoveryDays
        })
      });
      if (!res.ok) throw new Error('Failed to save report');
      
      toast.success('Analysis complete and saved');
      fetchReports(selectedPatient.id);
    } catch (error) {
      toast.error('Analysis failed. Please check your API key or symptoms.');
      console.error("Analysis failed", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans">
      <Toaster position="top-right" />
      
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white border-r border-slate-200 p-6 z-50">
        <div className="flex items-center gap-3 mb-10">
          <div className="p-2 bg-emerald-500 rounded-lg text-white">
            <Activity size={24} />
          </div>
          <h1 className="font-bold text-xl tracking-tight">HealthPredict</h1>
        </div>

        <nav className="space-y-2">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
            { id: 'analyze', label: 'AI Analysis', icon: BrainCircuit },
            { id: 'anatomy', label: 'X-Ray Anatomy', icon: Layers },
            { id: 'reports', label: 'Patient Reports', icon: FileText },
          ].map((item) => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                activeTab === item.id ? "bg-emerald-50 text-emerald-700 font-medium" : "text-slate-500 hover:bg-slate-50"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-8 left-6 right-6">
          <div className="p-4 bg-slate-900 rounded-2xl text-white">
            <div className="flex items-center gap-2 mb-2">
              <Database size={16} className="text-emerald-400" />
              <span className="text-xs font-medium uppercase tracking-wider opacity-60">System Status</span>
            </div>
            <p className="text-sm font-medium">ML Pipeline Active</p>
            <div className="mt-3 h-1 w-full bg-white/10 rounded-full overflow-hidden">
              <div className="h-full w-4/5 bg-emerald-400 rounded-full" />
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-8">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">
              {activeTab === 'dashboard' && "Health Analytics Overview"}
              {activeTab === 'analyze' && "Predictive Inference Engine"}
              {activeTab === 'reports' && "Clinical Records"}
              {activeTab === 'anatomy' && "X-Ray Anatomy Visualization"}
            </h2>
            <p className="text-slate-500">Regression-based ML modeling for healthcare outcomes.</p>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsAddPatientOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-all shadow-sm"
            >
              <Plus size={18} />
              Add Patient
            </button>
            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="text-right">
                <p className="text-sm font-bold">Dr. Sarah Chen</p>
                <p className="text-xs text-slate-500">Chief Medical Analyst</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                <User size={20} className="text-slate-500" />
              </div>
            </div>
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-4 gap-6">
              {[
                { label: 'Total Patients', value: patients.length.toLocaleString(), icon: User, color: 'text-blue-600', bg: 'bg-blue-50' },
                { label: 'Accuracy Rate', value: '94.2%', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                { label: 'Avg Recovery', value: '12.4 Days', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
                { label: 'Risk Alerts', value: '18', icon: AlertCircle, color: 'text-rose-600', bg: 'bg-rose-50' },
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                  <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center mb-4", stat.bg)}>
                    <stat.icon className={stat.color} size={24} />
                  </div>
                  <p className="text-slate-500 text-sm font-medium mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-3 gap-6">
              <div className="col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h3 className="font-bold text-lg">Regression Model Performance</h3>
                    <p className="text-xs text-slate-500">Predicted vs Actual health outcomes over time.</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <select 
                      className="text-xs font-bold bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                      value={monthFilter}
                      onChange={(e) => setMonthFilter(e.target.value)}
                    >
                      <option value="All">All Months</option>
                      {trendData.map(d => <option key={d.month} value={d.month}>{d.month}</option>)}
                    </select>
                    <div className="flex gap-4 text-xs font-medium">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-emerald-500" />
                        <span>Predicted</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-slate-300" />
                        <span>Actual</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={filteredTrendData}>
                      <defs>
                        <linearGradient id="colorPredicted" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                        labelStyle={{ fontSize: '12px', color: '#64748b', marginBottom: '4px' }}
                      />
                      <Area type="monotone" dataKey="predicted" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorPredicted)" activeDot={{ r: 6, strokeWidth: 0 }} />
                      <Area type="monotone" dataKey="actual" stroke="#cbd5e1" strokeWidth={2} fill="transparent" strokeDasharray="5 5" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-lg mb-6">Recent Patients</h3>
                <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {patients.map(p => (
                    <button 
                      key={p.id}
                      onClick={() => setSelectedPatient(p)}
                      className={cn(
                        "w-full flex items-center gap-4 p-4 rounded-2xl transition-all text-left",
                        selectedPatient?.id === p.id ? "bg-slate-50 ring-1 ring-slate-200" : "hover:bg-slate-50"
                      )}
                    >
                      <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-sm">
                        {p.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-sm">{p.name}</p>
                        <p className="text-xs text-slate-500">{p.age}y • {p.blood_type}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analyze' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500 flex items-center justify-center text-white">
                  <BrainCircuit size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-xl">Predictive Inference</h3>
                  <p className="text-slate-500 text-sm">Enter patient symptoms for real-time regression analysis.</p>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Patient Selection</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    value={selectedPatient?.id || ''}
                    onChange={(e) => setSelectedPatient(patients.find(p => p.id === Number(e.target.value)) || null)}
                  >
                    {patients.map(p => <option key={p.id} value={p.id}>{p.name} ({p.age}y)</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Symptoms & Observations</label>
                  <textarea 
                    rows={4}
                    placeholder="Describe symptoms, duration, and severity..."
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 resize-none"
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                  />
                </div>

                <button 
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || !symptoms}
                  className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2"
                >
                  {isAnalyzing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Running ML Pipeline...
                    </>
                  ) : (
                    <>
                      <TrendingUp size={20} />
                      Generate Prediction
                    </>
                  )}
                </button>
              </div>
            </div>

            {prediction && (
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex justify-between items-start mb-8">
                  <h3 className="font-bold text-xl">Analysis Results</h3>
                  <div className="flex gap-3">
                    <button 
                      onClick={() => setActiveTab('anatomy')}
                      className="px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 hover:bg-blue-100 transition-colors"
                    >
                      <Layers size={14} />
                      View 3D Anatomy
                    </button>
                    <div className="px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider">
                      Model Confidence: 98.2%
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-8 mb-8">
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Predicted Diagnosis</p>
                    <p className="text-xl font-bold text-slate-900">{prediction.diagnosis}</p>
                  </div>
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Recovery Regression</p>
                    <p className="text-xl font-bold text-slate-900">{prediction.recoveryDays} Days <span className="text-sm font-normal text-slate-500">(Estimated)</span></p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-2">
                      <AlertCircle size={18} className="text-amber-500" />
                      Clinical Explanation
                    </h4>
                    <p className="text-slate-600 leading-relaxed">{prediction.explanation}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                      <CheckCircle2 size={18} className="text-emerald-500" />
                      Recommended Actions
                    </h4>
                    <ul className="grid grid-cols-1 gap-3">
                      {prediction.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-3 p-3 bg-emerald-50/50 rounded-xl text-sm text-emerald-800">
                          <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                            {i + 1}
                          </div>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'anatomy' && (
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white">
                    <Layers size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl">Interactive X-Ray Viewer</h3>
                    <p className="text-slate-500 text-sm">Radiological mapping of predicted patient health outcomes.</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setPrediction(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-sm font-bold transition-all flex items-center gap-2"
                  >
                    <RotateCw size={16} />
                    Reset Scan
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-8">
                <div className="col-span-3 aspect-video bg-[#000814] rounded-3xl relative overflow-hidden group border border-slate-800">
                  {/* Grid Background */}
                  <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#3b82f6 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
                  
                  {/* Scanning Line */}
                  <motion.div 
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    className="absolute left-0 right-0 h-[2px] bg-cyan-400/50 shadow-[0_0_15px_rgba(34,211,238,0.8)] z-20"
                  />

                  {/* Mock 3D Viewer */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div 
                      animate={{ rotateY: 360 }}
                      transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                      className="relative w-64 h-[500px]"
                    >
                      {/* X-Ray Glow */}
                      <div className="absolute inset-0 bg-cyan-500/5 blur-3xl rounded-full" />
                      
                      <div className="relative w-full h-full border-2 border-cyan-500/10 rounded-[120px] flex flex-col items-center justify-between py-12 px-8">
                        {/* Head */}
                        <div className="relative">
                          <div className={cn(
                            "w-14 h-14 rounded-full border-2 border-cyan-400/20 flex items-center justify-center transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Head' && "bg-rose-500/40 border-rose-500 shadow-[0_0_40px_rgba(244,63,94,0.8)] scale-110"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Head' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }}>
                            <BrainCircuit className={cn("transition-colors", prediction?.affectedBodyPart === 'Head' ? "text-white" : "text-cyan-400/40")} size={28} />
                          </div>
                        </div>

                        {/* Neck */}
                        <div className={cn(
                          "w-8 h-10 border-x-2 border-cyan-400/20 transition-all duration-1000",
                          prediction?.affectedBodyPart === 'Neck' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.6)]"
                        )}
                        style={{
                          backgroundColor: prediction?.affectedBodyPart === 'Neck' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                        }} />

                        {/* Chest / Thorax */}
                        <div className="relative">
                          <div className={cn(
                            "w-32 h-32 rounded-[40px] border-2 border-cyan-400/20 flex items-center justify-center transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Chest' && "bg-rose-500/40 border-rose-500 shadow-[0_0_50px_rgba(244,63,94,0.8)] scale-110"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Chest' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }}>
                            <Heart className={cn("transition-colors", prediction?.affectedBodyPart === 'Chest' ? "text-white animate-pulse" : "text-cyan-400/40")} size={40} />
                          </div>
                        </div>

                        {/* Abdomen */}
                        <div className="relative">
                          <div className={cn(
                            "w-28 h-24 rounded-[30px] border-2 border-cyan-400/20 flex items-center justify-center transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Abdomen' && "bg-rose-500/40 border-rose-500 shadow-[0_0_40px_rgba(244,63,94,0.7)] scale-110"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Abdomen' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }}>
                            <Activity className={cn("transition-colors", prediction?.affectedBodyPart === 'Abdomen' ? "text-white" : "text-cyan-400/40")} size={32} />
                          </div>
                        </div>

                        {/* Pelvis */}
                        <div className={cn(
                          "w-24 h-12 rounded-b-[40px] border-2 border-cyan-400/20 transition-all duration-1000",
                          prediction?.affectedBodyPart === 'Pelvis' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.6)]"
                        )}
                        style={{
                          backgroundColor: prediction?.affectedBodyPart === 'Pelvis' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                        }} />

                        {/* Spine (Background) */}
                        <div className={cn(
                          "absolute top-24 w-4 h-80 border-2 border-cyan-400/10 -z-10 transition-all duration-1000",
                          prediction?.affectedBodyPart === 'Spine' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.6)]"
                        )}
                        style={{
                          backgroundColor: prediction?.affectedBodyPart === 'Spine' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                        }} />

                        {/* Arms */}
                        <div className="absolute inset-x-0 top-32 flex justify-between -mx-12">
                           <div className={cn(
                            "w-6 h-48 rounded-full border-2 border-cyan-400/10 transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Arms' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.5)]"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Arms' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }} />
                           <div className={cn(
                            "w-6 h-48 rounded-full border-2 border-cyan-400/10 transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Arms' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.5)]"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Arms' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }} />
                        </div>

                        {/* Legs */}
                        <div className="absolute inset-x-0 bottom-0 flex justify-center gap-12">
                           <div className={cn(
                            "w-8 h-40 rounded-full border-2 border-cyan-400/10 transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Legs' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.5)]"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Legs' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }} />
                           <div className={cn(
                            "w-8 h-40 rounded-full border-2 border-cyan-400/10 transition-all duration-1000",
                            prediction?.affectedBodyPart === 'Legs' && "bg-rose-500/40 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.5)]"
                          )}
                          style={{
                            backgroundColor: prediction?.affectedBodyPart === 'Legs' ? `rgba(244, 63, 94, ${0.2 + (prediction.predictionScore * 0.6)})` : undefined
                          }} />
                        </div>
                      </div>
                    </motion.div>
                  </div>

                  {/* UI Overlays */}
                  <div className="absolute top-6 left-6 space-y-2">
                    {['Nervous', 'Circulatory', 'Respiratory', 'Digestive', 'Musculoskeletal', 'Endocrine'].map((sys) => (
                      <button 
                        key={sys} 
                        className={cn(
                          "block px-3 py-1.5 backdrop-blur-md border rounded-lg text-xs font-bold transition-all",
                          prediction?.affectedSystem === sys 
                            ? "bg-rose-500/80 border-rose-400 text-white shadow-lg shadow-rose-500/20" 
                            : "bg-white/5 border-white/10 text-cyan-400/60 hover:bg-white/10 hover:text-cyan-300"
                        )}
                      >
                        {sys} System
                      </button>
                    ))}
                  </div>

                  <div className="absolute bottom-6 right-6 p-4 bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl text-white">
                    <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-1">Radiological Focus</p>
                    <p className="text-sm font-bold text-cyan-400">
                      {prediction?.affectedBodyPart ? `${prediction.affectedBodyPart} Region` : 'System Scan Active'}
                    </p>
                    {prediction && (
                      <div className="mt-2 flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                        <span className="text-[10px] font-bold text-rose-300">Risk Intensity: {(prediction.predictionScore * 100).toFixed(1)}%</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-bold text-slate-900">Scan Vitals</h4>
                  {[
                    { label: 'Neural Activity', value: prediction?.affectedSystem === 'Nervous' ? 'Hyperactive' : '98%', color: 'bg-blue-500' },
                    { label: 'Cardiac Rhythm', value: prediction?.affectedSystem === 'Circulatory' ? 'Elevated' : '72 BPM', color: 'bg-rose-500' },
                    { label: 'Respiratory Rate', value: prediction?.affectedSystem === 'Respiratory' ? 'Irregular' : '16 BPM', color: 'bg-cyan-500' },
                    { label: 'Metabolic Rate', value: prediction?.affectedSystem === 'Digestive' ? 'Fluctuating' : 'Normal', color: 'bg-emerald-500' },
                  ].map((vital) => (
                    <div key={vital.label} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{vital.label}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-bold">{vital.value}</span>
                        <div className={cn("w-2 h-2 rounded-full", vital.color)} />
                      </div>
                    </div>
                  ))}
                  
                  <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800">
                    <p className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-2">Radiological Report</p>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {prediction 
                        ? `X-ray scan indicates primary involvement of the ${prediction.affectedSystem} system in the ${prediction.affectedBodyPart} region. Diagnosis: ${prediction.diagnosis}.`
                        : "Initiate patient analysis to generate a radiological mapping of health outcomes."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-bottom border-slate-200">
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Date</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Patient</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Diagnosis</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Risk Score</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Recovery</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {reports.map(report => (
                    <tr key={report.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-600">
                        {new Date(report.report_date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold">
                            {selectedPatient?.name.charAt(0)}
                          </div>
                          <span className="text-sm font-bold">{selectedPatient?.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-bold text-slate-900">{report.diagnosis}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className={cn(
                                "h-full rounded-full",
                                report.prediction_score > 0.7 ? "bg-rose-500" : 
                                report.prediction_score > 0.4 ? "bg-amber-500" : "bg-emerald-500"
                              )}
                              style={{ width: `${report.prediction_score * 100}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold text-slate-500">{(report.prediction_score * 100).toFixed(0)}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-slate-600">{report.recovery_days} Days</td>
                      <td className="px-6 py-4">
                        <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
                          <ArrowRight size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {reports.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">
                        No clinical reports found for this patient.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Add Patient Modal */}
      <AnimatePresence>
        {isAddPatientOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddPatientOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h3 className="text-xl font-bold">Register New Patient</h3>
                <button onClick={() => setIsAddPatientOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={20} className="text-slate-400" />
                </button>
              </div>
              <form onSubmit={handleAddPatient} className="p-8 space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Full Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                      value={newPatient.name}
                      onChange={(e) => setNewPatient({ ...newPatient, name: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Age</label>
                      <input 
                        required
                        type="number" 
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                        value={newPatient.age}
                        onChange={(e) => setNewPatient({ ...newPatient, age: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Gender</label>
                      <select 
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                        value={newPatient.gender}
                        onChange={(e) => setNewPatient({ ...newPatient, gender: e.target.value })}
                      >
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Blood Type</label>
                    <select 
                      className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                      value={newPatient.blood_type}
                      onChange={(e) => setNewPatient({ ...newPatient, blood_type: e.target.value })}
                    >
                      {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(t => <option key={t}>{t}</option>)}
                    </select>
                  </div>
                </div>
                <button 
                  type="submit"
                  disabled={isSubmittingPatient}
                  className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
                >
                  {isSubmittingPatient ? 'Registering...' : 'Complete Registration'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
