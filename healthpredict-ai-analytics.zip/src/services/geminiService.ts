import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface HealthPrediction {
  diagnosis: string;
  predictionScore: number; // 0-1 confidence or risk
  recoveryDays: number;
  explanation: string;
  recommendations: string[];
  affectedBodyPart: 'Head' | 'Neck' | 'Chest' | 'Abdomen' | 'Pelvis' | 'Spine' | 'Arms' | 'Legs' | 'General';
  affectedSystem: 'Nervous' | 'Circulatory' | 'Respiratory' | 'Digestive' | 'Musculoskeletal' | 'Endocrine' | 'General';
}

export async function getHealthPrediction(symptoms: string, patientData: any): Promise<HealthPrediction> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following patient symptoms and data to provide a regression-based health outcome prediction.
    
    Patient Data: ${JSON.stringify(patientData)}
    Symptoms: ${symptoms}
    
    Provide a diagnosis, a prediction score (0.0 to 1.0 representing risk or severity), an estimated recovery time in days, recommendations, and identify the primary affected body part and system.
    
    Body Parts: ['Head', 'Neck', 'Chest', 'Abdomen', 'Pelvis', 'Spine', 'Arms', 'Legs', 'General']
    Systems: ['Nervous', 'Circulatory', 'Respiratory', 'Digestive', 'Musculoskeletal', 'Endocrine', 'General']`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          diagnosis: { type: Type.STRING },
          predictionScore: { type: Type.NUMBER, description: "Risk score from 0.0 to 1.0" },
          recoveryDays: { type: Type.INTEGER, description: "Estimated days to recovery" },
          explanation: { type: Type.STRING },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          affectedBodyPart: { 
            type: Type.STRING, 
            enum: ['Head', 'Neck', 'Chest', 'Abdomen', 'Pelvis', 'Spine', 'Arms', 'Legs', 'General'] 
          },
          affectedSystem: {
            type: Type.STRING,
            enum: ['Nervous', 'Circulatory', 'Respiratory', 'Digestive', 'Musculoskeletal', 'Endocrine', 'General']
          }
        },
        required: ["diagnosis", "predictionScore", "recoveryDays", "explanation", "recommendations", "affectedBodyPart", "affectedSystem"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as HealthPrediction;
}
